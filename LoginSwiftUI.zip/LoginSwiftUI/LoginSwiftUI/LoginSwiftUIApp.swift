//
//  LoginSwiftUIApp.swift
//  LoginSwiftUI
//
//  Created by Sachin Kamal on 17/09/21.
//

import SwiftUI

@main
struct LoginSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
