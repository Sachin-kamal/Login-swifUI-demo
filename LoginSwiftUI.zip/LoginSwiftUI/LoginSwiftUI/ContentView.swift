//
//  ContentView.swift
//  LoginSwiftUI
//
//  Created by Sachin Kamal on 17/09/21.
//

import SwiftUI

let lightGreyColor = Color(red: 239.0/255.0, green: 243.0/255.0, blue: 244.0/255.0)


struct ContentView: View {
    @State var userName: String = ""
    @State var password: String = ""

    var body: some View {
        VStack {
            WelcomeText()
            UserImage()
            UserNameField(userName: userName)
            PasswordField(password: password)
            LoginText()
        }.padding(.bottom, 70)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct UserImage: View {
    var body: some View {
        Image("user")
            .resizable()
            .aspectRatio(contentMode: .fill)
            .frame(width: 120, height: 120, alignment: .center)
            .clipped()
            .cornerRadius(60)
            .padding(.bottom, 100)
    }
}

struct WelcomeText: View {
    var body: some View {
        Text("Welcome!")
            .font(.system(size: 40, weight: .bold, design: .default))
            .padding()
    }
}

struct UserNameField: View {
    @State var userName: String
    var body: some View {
        TextField("Enter User Name", text: $userName)
            .padding()
            .background(lightGreyColor)
            .cornerRadius(10)
            .frame( height: 60, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
            .padding(.leading, 20)
            .padding(.trailing, 20)
    }
}

struct PasswordField: View {
    @State var password: String
    var body: some View {
        SecureField("Enter Passwocrd", text: $password)
            .padding()
            .background(lightGreyColor)
            .cornerRadius(10)
            .frame( height: 60, alignment: .center)
            .padding(.leading, 20)
            .padding(.trailing, 20)
            .padding(.bottom, 50)
    }
}

struct LoginText: View {
    var body: some View {
        Text("Login")
            .padding()
            .font(.system(size: 20, weight: .regular, design: .default))
            .frame(width: 200, height: 50, alignment: .center)
            .background(Color.blue)
            .cornerRadius(10)
    }
}
